#ifndef PROJ_5_H
#define PROJ_5_H

#include <stdio.h>
#include <stdint.h>
#include <string.h>

#endif
